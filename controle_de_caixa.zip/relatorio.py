import datetime as d
from datetime import datetime

def cria_relatorio(nome, num, status):
    nome = nome[0]
    num = num
    status = status
    hoje = d.date.today()
    now = datetime.now()
    hora = now.hour
    minuto = now.minute
    secundos = now.second
    with open('documentos/{}.txt'.format(hoje), 'a', encoding="UTF-8") as arq:
        arq.write('O livro: {}, de numereção: {}, foi {} às {}:{}:{}\n'.format(nome, num, status, hora, minuto, secundos))
        arq.close()
