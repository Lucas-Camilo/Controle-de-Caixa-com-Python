from tkinter import *
from tkinter.messagebox import showinfo
import banco
import os

class biblioteca:
    def __init__(self):
        banco.criar_tabela()
        banco.cria_tabela_user()
        self.fundo = "#706666"
        self.icone = "imagens/favicon.ico"

        self.janela = Tk()
        self.janela.iconbitmap(self.icone)

        self.nome = Frame(self.janela)
        self.nome.config(bg=self.fundo)
        self.nome.pack(pady=10)

        self.senha = Frame(self.janela)
        self.senha.config(bg=self.fundo)
        self.senha.pack(pady=10)

        self.button = Frame(self.janela)
        self.button.config(bg=self.fundo)
        self.button.pack(padx=10)
        self.janela.geometry("300x150")
        self.janela.title("ADUSMEC")
        self.janela.config(bg=self.fundo)

        Label(self.nome, text="User", font=10, bg=self.fundo).pack(side=LEFT)
        self.user = Entry(self.nome)
        self.user.pack(side=LEFT, padx=10)

        Label(self.senha, text="Senha", font=10, bg=self.fundo).pack(side=LEFT)
        self.senhaUser = Entry(self.senha, show="*")
        self.senhaUser.pack(side=LEFT, padx=10)

        self.btnlogar = Button(self.button, text="Login", width=15, height=2, command=self.btnlogin)
        self.btnlogar.pack()

        self.janela.mainloop()
    def btnlogin(self):
        usuario = self.user.get().strip()
        senha = self.senhaUser.get().strip()

        if usuario == "Angela" and senha == "123":
            showinfo("Bem Vinda", "Seja bem vinda Angela, espero que goste do seu programa")
            self.chama_principal()
        elif usuario == "" or senha == "":
            showinfo("Por favor", "Por favor preenha os campos")
            self.user.focus()
        else:
            showinfo("Erro", "Usuario ou senha incorretos,\n verifique se o CapsLook esta ativo")
    def chama_principal(self):
        self.janela.destroy()
        self.principal = Tk()
        self.principal.config(bg="Blue")
        self.principal.iconbitmap(self.icone)
        self.principal.title("ADUSMEC")
        self.principal.geometry("500x250")

        self.frame_botoes = Frame(self.principal)
        self.frame_botoes.config(bg="Blue")

        icone = PhotoImage(file="imagens/label_livro.png")
        consulta = PhotoImage(file="imagens/consulta.png")
        adiciona = PhotoImage(file="imagens/adicionar.png")
        relatorio = PhotoImage(file="imagens/relatorio.png")
        baixa = PhotoImage(file="imagens/baixa.png")

        Label(self.principal, image=icone, bg="Blue").pack(anchor=N, pady=10)
        self.frame_botoes.pack()
        Button(self.frame_botoes, image=consulta, bg="Blue", command=self.procura_livo).pack(side=LEFT, padx=10)
        Button(self.frame_botoes, image=adiciona, bg="Blue", command=self.adiciona).pack(side=LEFT, padx=10)
        Button(self.frame_botoes, image=baixa, bg="Blue", command=self.dar_baixa).pack(side=LEFT, padx=10)
        Button(self.frame_botoes, image=relatorio, bg="Blue", command=self.btn_relatorio).pack(side=LEFT, padx=10)
        self.principal.mainloop()
    def adiciona(self):
        self.adiciona = Toplevel()
        self.adiciona.iconbitmap(self.icone)
        self.adiciona.title("Adciona")
        self.adiciona.config(bg="Blue")
        Label(self.adiciona, text="OPAA, novo livro a Bordo", font=10, bg="Blue").pack()
        lista_nome = Frame(self.adiciona, bg="Blue")
        lista_genero = Frame(self.adiciona, bg="Blue")
        lista_subgenero = Frame(self.adiciona, bg="Blue")
        lista_autor = Frame(self.adiciona, bg="Blue")
        lista_preco = Frame(self.adiciona, bg="Blue")
        lista_quant = Frame(self.adiciona, bg=self.fundo)
        lista_numero = Frame(self.adiciona, bg="Blue")

        lista_nome.pack()
        lista_genero.pack()
        lista_subgenero.pack()
        lista_autor.pack()
        lista_preco.pack()
        lista_quant.pack()
        lista_numero.pack()

        Label(lista_nome, text="Nome do livro: ", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.Nome_livro = Entry(lista_nome)
        self.Nome_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_genero, text="Genero: ", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.genero_livro = Entry(lista_genero)
        self.genero_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_subgenero, text="Subgenero: ", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.subgenero_livro = Entry(lista_subgenero)
        self.subgenero_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_autor,text="Autor: ", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.autor_livro = Entry(lista_autor)
        self.autor_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_preco, text="Preço: ", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.preco_livro = Entry(lista_preco)
        self.preco_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_quant, text="Quantidade:", font=10, bg=self.fundo).pack(side=LEFT, padx=10, pady=10)
        self.quant_livro = Entry(lista_quant)
        self.quant_livro.pack(side=LEFT, padx=10, pady=10)

        Label(lista_numero, text="Numeração", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.num_livro = Entry(lista_numero)
        self.num_livro.pack(side=LEFT, padx=10, pady=10)

        Button(self.adiciona, text="Adcionar", width=15, height=2, command=self.inserir_banco).pack(padx=10, pady=20)
        Button(self.adiciona, text="Adcionar Doação", width=15, height=2, command=self.btnsomar).pack(padx=10, pady=20)
        self.adiciona.mainloop()

    def inserir_banco(self):
        nome = self.Nome_livro.get().strip().upper()
        genero = self.genero_livro.get().strip().upper()
        subgenero = self.subgenero_livro.get().strip().upper()
        autor = self.autor_livro.get().strip().upper()
        preco = self.preco_livro.get().strip().upper()
        quant = self.quant_livro.get().strip().upper()
        num = self.num_livro.get().strip().upper()
        if quant == "" or quant.isdigit() == False:
            showinfo("Desculpe", "Você inseriu um valor incorreto a quantidade será 1")
            quant = 1
        if nome == "":
            showinfo("Favor", "Digite o nome do Livro")
            self.Nome_livro.focus()
        elif genero =="":
            showinfo("Favor", "Digite o genero do Livro")
            self.genero_livro.focus()
        elif subgenero == "":
            showinfo("Favor", "Digite o subgenero do Livro")
            self.subgenero_livro.focus()
        elif preco == "":
            showinfo("Favor", "Digite o preço do Livro")
            self.preco_livro.focus()
        elif num == "" or num.isdigit() == False:
            showinfo("Favor", "Digite a Numeração do livro ")
            self.quant_livro.focus()
        elif autor == "":
            showinfo("Favor", "Digite o autor do livro")
            self.autor_livro.focus()
        else:
            validade = bool(banco.inserir_livro(nome, genero, subgenero, autor, preco, quant, num))
            if validade == True:
                showinfo("Sucesso", "O livro ja esta em seu acervo")
                self.adiciona.destroy()
    def btnsomar(self):
        print("Inserção de livros no sistema")
        quant = self.quant_livro.get().strip()
        num = self.num_livro.get().strip().upper()
        if num == "":
            showinfo("Favor", "Digite a Numeração do livro ")
            self.quant_livro.focus()
        if quant == "" or quant.isdigit() == False:
            showinfo("Desculpe", "Você inseriu um valor incorreto a quantidade será 1")
            quant = 1
        else:
            validade = banco.soma(num, quant)
            if validade == True:
                showinfo("Sucesso", "livro doado com sucesso")
    def dar_baixa(self):
        self.baixa = Toplevel()
        self.baixa.config(bg="Blue")
        self.baixa.iconbitmap(self.icone)
        self.baixa.title("Baixa")
        Label(self.baixa, text="Preencha o campo para encontrar o livro", font=10, bg="Blue").pack(pady=10)
        info = Frame(self.baixa, bg=self.fundo)
        info.pack()

        Label(info, text="Numeração do Livro", bg=self.fundo, font=10).pack(side=LEFT, pady=10, padx=10)
        self.num = Entry(info)
        self.num.pack(side=LEFT, padx=10, pady=10)

        Button(self.baixa, text="Dar Baixa", font=10, width=15, height=2, command=self.btnbaixa).pack(padx=10, pady=20)
        self.baixa.mainloop()
    def btnbaixa(self):
        numero = self.num.get().strip()
        if numero == "":
            showinfo("Favor", "Insira o numero de identificação")
            self.num.focus()
        elif numero.isdigit() == False:
            showinfo("Favor", "Digite um numero")
            self.num.focus()
        else:
            banco.remove_livro(numero)
            banco.aumenta_valor(numero)
            self.baixa.destroy()
    def procura_livo(self):
        self.janela_procura = Toplevel()
        self.janela_procura.config(bg="Blue")
        self.janela_procura.title("Procurar")
        self.janela_procura.iconbitmap(self.icone)
        nome_livro = Frame(self.janela_procura, bg="Blue")

        nome_livro.pack()

        Label(nome_livro, text="Nome do livro:", font=10, bg="Blue").pack(side=LEFT, padx=10, pady=10)
        self.nome_livro = Entry(nome_livro)
        self.nome_livro.pack(side=LEFT, padx=10, pady=10)

        Button(self.janela_procura, text="Procurar", width=15, height=2, command=self.btnProcura).pack(padx=10, pady=20)

        self.janela_procura.mainloop()
    def btnProcura(self):
        nome = self.nome_livro.get().strip().upper()
        if nome == "":
            showinfo("Favor", "Insira um nome")
            self.nome_livro.focus()
        else:
            result = banco.procura_livro(nome)
            if result == None or result == []:
                showinfo("ERRO", "LIVRO NÃO ACHADO")
            else:
                result_pesquisa = Toplevel()
                result_pesquisa.config(bg="Blue")
                for linha in result:
                    resultado = "Nome: {}, numero: {}, preço: {:.2f}".format(linha[0], linha[1], linha[2])
                    Label(result_pesquisa, text=resultado, font=10, bg="Blue").pack(padx=10, pady=10)
                Button(result_pesquisa, text="SAIR", width=15, height=2, command=result_pesquisa.destroy).pack(padx=10, pady=20)
                result_pesquisa.mainloop()
    def btn_relatorio(self):
        relatorio_janela = Toplevel(bg="Blue")
        Label(relatorio_janela, text="Esse é o total vendido", bg="Blue", font=10).pack(padx=10, pady=10)
        resultado = banco.conseguindo_valor()
        valor = resultado[0][0]
        Label(relatorio_janela, text="R$ {}".format(valor), font=10, bg="Blue").pack()
        Label(relatorio_janela, text="Esses são os relatorios", bg="Blue", font=10).pack(padx=10, pady=10)
        for file in os.listdir("documentos"):
            texto = file
            Label(relatorio_janela, text=texto, bg="Blue", font=10).pack(padx=10, pady=10)
        relatorio_janela.mainloop()



biblioteca()