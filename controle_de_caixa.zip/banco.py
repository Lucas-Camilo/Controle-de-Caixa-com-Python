import sqlite3
from tkinter.messagebox import showinfo
import relatorio
def criar_tabela():
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS livro (
                 nome varchar(30) NOT NULL,
                 genero varchar(30) NOT NULL,
                 subgenero varchar(30) NOT NULL,
                 autor varchar(30) NOT NULL,
                 preco float NOT NULL,
                 quant int NOT NULL,
                 numero int NOT NULL,
                 PRIMARY KEY(numero));""")
    conecao.commit()
    conecao.close()
def cria_tabela_user():
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS valores (
                    numero int NOTT NULL,
                    vendidos float NOT NULL);""")
    conecao.commit()
    conecao.close()
def aumenta_valor(num):
    num = num
    valor = get_valor(num)
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    c.execute(""" UPDATE valores SET vendidos = (vendidos +{})  WHERE numero = 1; """.format(valor[0][0]))
    conecao.commit()
    conecao.close()
def conseguindo_valor():
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute(""" SELECT vendidos FROM valores WHERE numero = 1; """)
        conecao.commit()
        return c.fetchall()
    except sqlite3.Error as erro:
        showinfo("ERRO", "Desculpe {}".format(erro))
    finally:
        conecao.close()
def inserir_livro(nome, genero, subgenero, autor, preco, quant, numero):
    nome = nome
    genero = genero
    subgenero = subgenero
    autor = autor
    preco = preco
    quant = quant
    numero = numero
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute(
            """INSERT INTO livro(nome,genero,subgenero,autor,preco,quant, numero) values('{}','{}','{}','{}','{}','{}','{}');""".format(nome, genero,
                                                                                                       subgenero, autor,
                                                                                                       preco,quant, numero))
        conecao.commit()
        relatorio.cria_relatorio(nome, numero, "Adcionado ao acervo")
        return True
    except sqlite3.Error as erro:
        showinfo("ERRO", "Desculpe {}".format(erro))
        return False
    finally:
        conecao.close()

def remove_livro(numero):
    numero = numero
    nome = get_nome(numero)
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute("""UPDATE livro SET quant = (quant - 1) WHERE numero = {}""".format(numero))
        conecao.commit()
        relatorio.cria_relatorio(nome, numero, "Vendido")
        showinfo("Completo", "Livro Retirado com Sucesso")
    except sqlite3.Error as erro:
        showinfo("ERRO", "{}".format(erro))

def get_nome(num):
    numero = num
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute("""SELECT nome FROM livro WHERE numero = {}""".format(numero))
        conecao.commit()
        return c.fetchone()
    except sqlite3.Error as erro:
        showinfo("ERRO", "{}".format(erro))
        return "Desconhecido"

def procura_livro(nome):
    nome = nome
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute("""SELECT nome, numero, preco FROM livro WHERE nome LIKE "%{}%" AND quant > 0; """.format(nome))
        conecao.commit()
        return c.fetchall()
    except sqlite3.Error as erro:
        showinfo("ERRO", "{}".format(erro))

def soma(num,quant):
    numero = num
    quant = quant
    nome = get_nome(numero)
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute("""UPDATE livro SET quant = (quant + {}) WHERE numero = {}""".format(quant, numero))
        conecao.commit()
        relatorio.cria_relatorio(nome, numero, "Doado")
        showinfo("Completo", "Livro Acrescentado com Sucesso")
        return True
    except sqlite3.Error as erro:
        showinfo("ERRO", "{}".format(erro))
        return False
def get_valor(num):
    num = num
    conecao = sqlite3.connect("banco/Biblioteca.db")
    c = conecao.cursor()
    try:
        c.execute(""" SELECT preco FROM livro WHERE numero = {}""".format(num))
        conecao.commit()
        showinfo("Completo", "Livro Acrescentado com Sucesso")
        return c.fetchall()
    except sqlite3.Error as erro:
        showinfo("ERRO", "{}".format(erro))
